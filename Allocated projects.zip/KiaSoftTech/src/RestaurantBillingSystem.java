import java.util.Scanner;
public class RestaurantBillingSystem {
  public static void main(String[] args) {
   @SuppressWarnings("resource")
	Scanner input = new Scanner(System.in);
	String[] items = new String[]        {"Cold Coffee ","Ice-Cream ","Masala-Chai ","plain-Thali","Paneer Dosa ","Veg-Pizza ","Burger ","Maggi ","Petties ","Quit "};
	int[] rate = new int[]{250,100,40,120,270,300,90,100,90,0};
	int[] quantity = new int[10];
       int sum=0;
	   boolean quit=true;
         System.out.println("***Hello, WELCOME to K&F Restaurant***\n");
        do{
            System.out.println("ITEMS"+"\t\t\tPrice\n");
		for(int i=0;i<10;i++)
            System.out.println((i+1)+"."+items[i]+"\t\t"+rate[i]);
		    System.out.println("Please enter the no that you would like to order:");
	        int choice=input.nextInt();
		if(choice>0 && choice<10)
	     {
		   System.out.println("enter the no of quantites of "+items[choice-1]);
             int q=input.nextInt();
	         quantity[choice-1]+=q;
	     }
	    else{
               quit=false;
            }
		  }
		while(quit);
          System.out.println("Your Orders are:\n");
	    for(int i=0;i<10;i++){
            if(quantity[i]!=0){
	          sum+=quantity[i]*rate[i];
              System.out.println(items[i]+"*"+quantity[i]+" == "+quantity[i]*rate[i]+" rs");
	     }
	    }
         System.out.println("Your total bill is -> "+sum+" rs");
         System.out.println("Thank you");
	}  
}